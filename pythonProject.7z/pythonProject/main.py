'''
zapotrzebowanie na pomarańcze, uran i tuńczyka losowane jest na początku, ale łączna losowana wielkość wynosi pomiędzy
100kg a 200kg dla punktu, tj. punkt może oczekiwać dostarczenia: 50 kg pomarańczy, 50 kg tuńczyka i 50 kg uranu; albo
tylko 200kg uranu, albo tylko 100 kg tuńczyka i tak dalej;
'''

import random


class Demand:

    def __init__(self, point):
        self._point = point
        self._oranges = 0
        self._uranium = 0
        self._tuna = 0
        self._check = random.randint(100, 200)

    @property
    def point(self):
        return self._point

    @property
    def oranges(self):
        return self._oranges

    @property
    def uranium(self):
        return self._uranium

    @property
    def tuna(self):
        return self._tuna

    @property
    def check(self):
        return self._check

    @point.setter
    def point(self, value) -> None:
        self._point = value

    def _capacity(self):
        self.oranges = random.randint(100, self.check)
